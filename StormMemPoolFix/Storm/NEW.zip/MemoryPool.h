﻿/**
 * MemoryPool.h - 修复版本，完全兼容Storm的大块格式
 *
 * 【关键修复】：
 * 1. 使用Storm原版的14字节头部结构
 * 2. 正确设置flags=0x0C（0x04|0x08）
 * 3. 实现外部元数据区管理
 * 4. Size字段只表示头部大小，不是用户数据大小
 */
#pragma once
#include <cstdint>
#include <cstddef>
#include <atomic>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <vector>
#include <Windows.h>

 // 【核心修复】Storm原版大块头部结构 - 14字节
#pragma pack(push, 1)
struct StormBigBlockHeader {
    uint16_t BlockHdrSize;    // 固定0x000E (14字节) - 只表示头部大小
    uint8_t  AlignPad;        // 固定0 - 大块模式无需对齐
    uint8_t  Flags;           // 0x0C (0x04|0x08) - 大块+特殊指针标志
    uint32_t HeapStub;        // 0xC0DEFEED - Storm占位指针
    uint32_t MetaPtr;         // 指向外部元数据区的指针
    uint16_t FrontMagic;      // 0x6F6D - 前哨魔数
};
#pragma pack(pop)

// 【核心修复】外部元数据区结构 - 16字节
#pragma pack(push, 1)
struct StormBigBlockMeta {
    uint32_t RealUserSize;       // 真正的用户数据大小
    uint16_t BlockHdrSizeCopy;   // 头部大小备份 (14)
    uint16_t MetaMagic;          // 0x0C00 - 元数据魔数
    uint32_t HeapIdCopy;         // Storm堆ID备份
    uint32_t Reserved;           // 保留字段，对齐到16字节
};
#pragma pack(pop)

// Storm大块常量（修复版）
namespace StormBigBlockConst {
    // 【修复】正确的标志位组合
    constexpr uint8_t  BIG_BLOCK_FLAGS = 0x0C;        // 0x04|0x08，大块+特殊指针
    constexpr uint8_t  VIRTUALALLOC_FLAG = 0x04;      // VirtualAlloc大块标志
    constexpr uint8_t  SPECIAL_PTR_FLAG = 0x08;       // 特殊指针标志

    // 魔数和占位符
    constexpr uint16_t FRONT_MAGIC = 0x6F6D;          // 前哨魔数
    constexpr uint16_t META_MAGIC = 0x0C00;           // 元数据魔数
    constexpr uint32_t PLACEHOLDER_HEAP = 0xC0DEFEED; // 占位HeapPtr

    // 大小常量
    constexpr size_t   HEADER_SIZE = 14;               // Storm头部：14字节
    constexpr size_t   META_SIZE = 16;                 // 外部元数据：16字节
    constexpr size_t   TOTAL_OVERHEAD = HEADER_SIZE + META_SIZE; // 总开销：30字节

    // 对齐和填充
    constexpr uint8_t  ALIGN_PAD = 0;                 // 大块模式固定alignPad=0
    constexpr uint16_t BLOCK_HDR_SIZE = 14;           // 固定头部大小

    // 【关键】阈值建议
    constexpr size_t   STORM_THRESHOLD = 0xFE7B;      // Storm内部阈值≈64KB
    constexpr size_t   RECOMMENDED_MIN = 64 * 1024;   // 推荐最小64KB
    constexpr size_t   CONSERVATIVE_MIN = 128 * 1024; // 保守最小128KB
}

/**
 * 【修复版】设置Storm兼容大块头部
 * 布局：[外部元数据16字节] [Storm头部14字节] -> [用户数据]
 *
 * @param metaPtr 外部元数据区指针（VirtualAlloc分配）
 * @param userSize 用户请求的数据大小
 * @return 用户数据指针
 */
inline void* SetupStormBigBlockHeader(void* metaPtr, size_t userSize) {
    if (!metaPtr) return nullptr;

    // 1. 设置外部元数据区（metaPtr开始的16字节）
    auto* meta = static_cast<StormBigBlockMeta*>(metaPtr);
    meta->RealUserSize = static_cast<uint32_t>(userSize);
    meta->BlockHdrSizeCopy = StormBigBlockConst::BLOCK_HDR_SIZE;
    meta->MetaMagic = StormBigBlockConst::META_MAGIC;
    meta->HeapIdCopy = StormBigBlockConst::PLACEHOLDER_HEAP;
    meta->Reserved = 0;

    // 2. 设置Storm头部（metaPtr+16开始的14字节）
    uint8_t* headerStart = static_cast<uint8_t*>(metaPtr) + StormBigBlockConst::META_SIZE;
    auto* header = reinterpret_cast<StormBigBlockHeader*>(headerStart);

    header->BlockHdrSize = StormBigBlockConst::BLOCK_HDR_SIZE;  // 【关键】只表示头部大小
    header->AlignPad = StormBigBlockConst::ALIGN_PAD;
    header->Flags = StormBigBlockConst::BIG_BLOCK_FLAGS;         // 【关键】0x0C标志
    header->HeapStub = StormBigBlockConst::PLACEHOLDER_HEAP;
    header->MetaPtr = reinterpret_cast<uint32_t>(metaPtr);       // 指向元数据区
    header->FrontMagic = StormBigBlockConst::FRONT_MAGIC;

    // 3. 返回用户数据指针
    return headerStart + StormBigBlockConst::HEADER_SIZE;
}

/**
 * 【修复版】验证Storm大块
 */
inline bool ValidateStormBigBlock(void* userPtr) {
    if (!userPtr) return false;

    __try {
        uint8_t* userBytes = static_cast<uint8_t*>(userPtr);

        // 1. 检查前哨魔数（userPtr-2位置）
        uint16_t frontMagic = *reinterpret_cast<uint16_t*>(userBytes - 2);
        if (frontMagic != StormBigBlockConst::FRONT_MAGIC) {
            return false;
        }

        // 2. 检查Storm头部（userPtr-14位置）
        auto* header = reinterpret_cast<StormBigBlockHeader*>(userBytes - StormBigBlockConst::HEADER_SIZE);

        // 3. 验证关键字段
        if (header->BlockHdrSize != StormBigBlockConst::BLOCK_HDR_SIZE) return false;
        if (header->AlignPad != StormBigBlockConst::ALIGN_PAD) return false;
        if ((header->Flags & StormBigBlockConst::VIRTUALALLOC_FLAG) == 0) return false; // 必须有0x04
        if (header->HeapStub != StormBigBlockConst::PLACEHOLDER_HEAP) return false;

        // 4. 验证外部元数据
        if (header->MetaPtr == 0) return false;
        auto* meta = reinterpret_cast<StormBigBlockMeta*>(header->MetaPtr);

        if (meta->BlockHdrSizeCopy != StormBigBlockConst::BLOCK_HDR_SIZE) return false;
        if (meta->MetaMagic != StormBigBlockConst::META_MAGIC) return false;

        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

/**
 * 【修复版】从userPtr获取metaPtr
 */
inline void* GetMetaPtrFromBigBlock(void* userPtr) {
    if (!userPtr) return nullptr;

    __try {
        uint8_t* userBytes = static_cast<uint8_t*>(userPtr);
        auto* header = reinterpret_cast<StormBigBlockHeader*>(userBytes - StormBigBlockConst::HEADER_SIZE);
        return reinterpret_cast<void*>(header->MetaPtr);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return nullptr;
    }
}

/**
 * 【修复版】从userPtr获取Storm头部指针
 */
inline StormBigBlockHeader* GetHeaderFromBigBlock(void* userPtr) {
    if (!userPtr) return nullptr;

    uint8_t* userBytes = static_cast<uint8_t*>(userPtr);
    return reinterpret_cast<StormBigBlockHeader*>(userBytes - StormBigBlockConst::HEADER_SIZE);
}

/**
 * 【修复版】获取大块的真实用户数据大小
 */
inline size_t GetBigBlockUserSize(void* userPtr) {
    if (!userPtr) return 0;

    __try {
        void* metaPtr = GetMetaPtrFromBigBlock(userPtr);
        if (!metaPtr) return 0;

        auto* meta = static_cast<StormBigBlockMeta*>(metaPtr);
        return meta->RealUserSize;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
}

/**
 * 【修复版】计算需要VirtualAlloc的总大小
 */
inline size_t CalculateTotalAllocSize(size_t userSize) {
    // 总大小 = 外部元数据(16) + Storm头部(14) + 用户数据 + 页对齐
    size_t totalSize = StormBigBlockConst::TOTAL_OVERHEAD + userSize;

    // 向上对齐到4KB页边界
    size_t pageSize = 4096;
    return (totalSize + pageSize - 1) & ~(pageSize - 1);
}

// 大块元数据（简化版，用于内部跟踪）
struct BigBlockMetadata {
    size_t userSize;
    size_t totalAllocSize;      // VirtualAlloc的总大小
    const char* sourceFile;
    uint32_t sourceLine;
    uint64_t timestamp;
    uint32_t threadId;
    void* metaPtr;              // VirtualAlloc的起始指针
    void* userPtr;              // 用户数据指针
    bool wasFreed;
};

// 内存池统计信息
struct BigBlockPoolStats {
    std::atomic<size_t> bigBlocksAllocated{ 0 };
    std::atomic<size_t> bigBlocksFreed{ 0 };
    std::atomic<size_t> fallbackAllocs{ 0 };
    std::atomic<size_t> currentBigBlockUsage{ 0 };
    std::atomic<size_t> peakBigBlockUsage{ 0 };
    std::atomic<size_t> tlsfPoolUsage{ 0 };
    std::atomic<size_t> tlsfPoolSize{ 0 };
    std::atomic<size_t> virtualAllocCalls{ 0 };    // VirtualAlloc调用次数
    std::atomic<size_t> virtualAllocBytes{ 0 };    // VirtualAlloc总字节数
};

// Storm兼容内存池类（修复版）
class StormCompatibleMemoryPool {
public:
    StormCompatibleMemoryPool() = default;
    ~StormCompatibleMemoryPool() = default;

    static bool Initialize();
    static void Shutdown();
    static StormCompatibleMemoryPool& GetInstance();

    void SetOriginalFunctions(void* alloc, void* free, void* realloc);

    // 【核心接口】大块专用函数（修复版）
    void* AllocateBigBlock(size_t userSize, const char* filename = nullptr, uint32_t line = 0);
    bool FreeBigBlock(void* userPtr, const char* filename = nullptr, uint32_t line = 0);
    void* ReallocateBigBlock(void* oldPtr, size_t newSize, const char* filename = nullptr, uint32_t line = 0);

    // 【查询接口】
    bool IsOurBigBlock(void* ptr) const;
    size_t GetBigBlockSize(void* userPtr) const;
    bool ValidateBigBlock(void* ptr) const;

    // 【统计和管理】
    const BigBlockPoolStats& GetStats() const { return m_stats; }
    void PrintStats() const;
    void CleanupPool();

    // 【TLSF基础接口】
    bool InitializeTLSF();
    void ShutdownTLSF();
    size_t GetTLSFUsage() const;
    size_t GetTLSFSize() const;
    bool CheckTLSFIntegrity();

    // 【调试接口】
    void DebugDumpBigBlock(void* userPtr);
    bool RunBigBlockTest(int iterations = 100);

private:
    // 【内部实现】VirtualAlloc版本
    void* VirtualAllocBigBlock(size_t userSize);
    bool VirtualFreeBigBlock(void* userPtr);

    // 【内部实现】TLSF版本（保留）
    void* TLSFAllocateAligned(size_t size);
    void TLSFFreeSafe(void* ptr);

    void RegisterBigBlock(void* userPtr, const BigBlockMetadata& metadata);
    bool UnregisterBigBlock(void* userPtr);
    bool GetBigBlockMetadata(void* userPtr, BigBlockMetadata& metadata) const;

private:
    static std::atomic<bool> s_initialized;
    static std::unique_ptr<StormCompatibleMemoryPool> s_instance;
    static std::mutex s_initMutex;

    // 【原始函数指针】
    void* m_origStormAlloc = nullptr;
    void* m_origStormFree = nullptr;
    void* m_origStormRealloc = nullptr;

    // 【线程安全】
    mutable std::mutex m_tlsfMutex;
    mutable std::mutex m_metadataMutex;

    // 【数据结构】
    std::unordered_map<void*, BigBlockMetadata> m_bigBlockMetadata;
    BigBlockPoolStats m_stats;

    // 【TLSF池】保留用于将来可能的混合模式
    void* m_tlsfPool = nullptr;
    void* m_tlsfMemory = nullptr;
    size_t m_tlsfSize = 64 * 1024 * 1024;

    // 【配置】
    bool m_useVirtualAlloc = true;  // 当前版本强制使用VirtualAlloc
    size_t m_bigBlockThreshold = StormBigBlockConst::CONSERVATIVE_MIN; // 128KB保守阈值

    // 【禁用拷贝】
    StormCompatibleMemoryPool(const StormCompatibleMemoryPool&) = delete;
    StormCompatibleMemoryPool& operator=(const StormCompatibleMemoryPool&) = delete;
};

// 【全局实例】
#define g_MemoryPool StormCompatibleMemoryPool::GetInstance()

// 【便捷宏】
#define STORM_BIG_ALLOC(size) g_MemoryPool.AllocateBigBlock(size, __FILE__, __LINE__)
#define STORM_BIG_FREE(ptr) g_MemoryPool.FreeBigBlock(ptr, __FILE__, __LINE__)
#define STORM_BIG_REALLOC(ptr, size) g_MemoryPool.ReallocateBigBlock(ptr, size, __FILE__, __LINE__)