﻿/**
 * MemoryPool.cpp - 修复版本，使用VirtualAlloc + Storm兼容头部
 *
 * 【关键修复】：
 * 1. 移除Size字段溢出检查（新版本不会溢出）
 * 2. 使用VirtualAlloc直接分配大块，绕过TLSF
 * 3. 实现完整的Storm兼容头部格式
 * 4. 正确的外部元数据区管理
 * 5. 支持Storm的释放流程
 */

#include "pch.h"
#include "MemoryPool.h"
#include "Storm/StormOffsets.h"
#include "Storm/StormHook.h"
#include <Windows.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include "tlsf.h"

 // 静态成员初始化
std::atomic<bool> StormCompatibleMemoryPool::s_initialized{ false };
std::unique_ptr<StormCompatibleMemoryPool> StormCompatibleMemoryPool::s_instance;
std::mutex StormCompatibleMemoryPool::s_initMutex;

// 外部全局变量
extern uintptr_t gStormDllBase;

// SEH保护模板
template<typename Func>
void SehProtect(Func&& fn, const char* when = nullptr) {
    __try {
        fn();
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        if (when)
            std::cerr << "[SEH] 捕获异常：" << when
            << " 错误: 0x" << std::hex << GetExceptionCode() << std::dec << std::endl;
        else
            std::cerr << "[SEH] 捕获异常，错误: 0x" << std::hex << GetExceptionCode() << std::dec << std::endl;
    }
}

// 获取单例
StormCompatibleMemoryPool& StormCompatibleMemoryPool::GetInstance()
{
    if (!s_initialized.load(std::memory_order_acquire)) {
        std::lock_guard<std::mutex> lock(s_initMutex);
        if (!s_initialized.load(std::memory_order_relaxed)) {
            s_instance.reset(new StormCompatibleMemoryPool);
            s_initialized.store(true, std::memory_order_release);
        }
    }
    return *s_instance;
}

bool StormCompatibleMemoryPool::Initialize() {
    auto& instance = GetInstance();

    std::cout << "[MemoryPool] 初始化VirtualAlloc大块模式内存池..." << std::endl;
    std::cout << "[MemoryPool] 阈值: " << (instance.m_bigBlockThreshold / 1024) << " KB" << std::endl;
    std::cout << "[MemoryPool] 头部格式: Storm兼容14字节 + 16字节元数据" << std::endl;

    // VirtualAlloc模式不需要初始化TLSF，但保留接口用于将来扩展
    return true;
}

void StormCompatibleMemoryPool::Shutdown() {
    if (s_initialized.load(std::memory_order_acquire)) {
        auto& instance = GetInstance();
        instance.ShutdownTLSF();

        std::lock_guard<std::mutex> lock(s_initMutex);
        s_instance.reset();
        s_initialized.store(false, std::memory_order_release);
    }
}

void StormCompatibleMemoryPool::SetOriginalFunctions(void* alloc, void* free, void* realloc) {
    m_origStormAlloc = alloc;
    m_origStormFree = free;
    m_origStormRealloc = realloc;

    std::cout << "[MemoryPool] 原始函数指针已设置（VirtualAlloc大块模式）" << std::endl;
}

/**
 * 【核心修复】分配大块内存 - VirtualAlloc版本
 * 1. 使用VirtualAlloc直接分配
 * 2. 设置Storm兼容的14字节头部 + 16字节元数据
 * 3. 不再有Size字段溢出问题
 */
void* StormCompatibleMemoryPool::AllocateBigBlock(size_t userSize,
    const char* filename,
    uint32_t line)
{
    if (userSize == 0) return nullptr;

    if (userSize < m_bigBlockThreshold) {
        std::cerr << "[MemoryPool] 警告：请求分配的不是大块: " << userSize
            << " < " << m_bigBlockThreshold << std::endl;
        return nullptr;
    }

    std::cout << "[MemoryPool] VirtualAlloc大块: " << (userSize / 1024) << " KB" << std::endl;

    // 【关键修复】使用VirtualAlloc版本
    void* userPtr = VirtualAllocBigBlock(userSize);
    if (!userPtr) {
        std::cerr << "[MemoryPool] VirtualAlloc大块分配失败，大小: " << userSize << std::endl;
        m_stats.fallbackAllocs.fetch_add(1, std::memory_order_relaxed);
        return nullptr;
    }

    // 【注册元数据】用于内部跟踪
    BigBlockMetadata meta{};
    meta.userSize = userSize;
    meta.totalAllocSize = CalculateTotalAllocSize(userSize);
    meta.sourceFile = filename ? filename : "<unknown>";
    meta.sourceLine = line;
    meta.timestamp = static_cast<uint64_t>(::GetTickCount64());
    meta.threadId = ::GetCurrentThreadId();
    meta.metaPtr = GetMetaPtrFromBigBlock(userPtr);
    meta.userPtr = userPtr;
    meta.wasFreed = false;

    RegisterBigBlock(userPtr, meta);

    // 【统计更新】
    m_stats.bigBlocksAllocated.fetch_add(1, std::memory_order_relaxed);
    m_stats.currentBigBlockUsage.fetch_add(meta.totalAllocSize, std::memory_order_relaxed);

    size_t currentUsage = m_stats.currentBigBlockUsage.load();
    size_t peakUsage = m_stats.peakBigBlockUsage.load();
    while (currentUsage > peakUsage &&
        !m_stats.peakBigBlockUsage.compare_exchange_weak(peakUsage, currentUsage)) {
        // 继续尝试更新峰值
    }

    std::cout << "[MemoryPool] VirtualAlloc大块分配成功: userPtr=" << userPtr
        << " userSize=" << userSize << " totalAlloc=" << meta.totalAllocSize << std::endl;

    return userPtr;
}

/**
 * 【核心修复】释放大块内存 - VirtualAlloc版本
 */
bool StormCompatibleMemoryPool::FreeBigBlock(void* userPtr,
    const char* filename,
    uint32_t line)
{
    if (!userPtr) return true;

    std::cout << "[MemoryPool] 释放VirtualAlloc大块: " << userPtr << std::endl;

    // 【验证是否是我们的块】
    if (!ValidateBigBlock(userPtr)) {
        std::cerr << "[MemoryPool] 释放无效的大块: " << userPtr << std::endl;
        return false;
    }

    // 【获取元数据】
    BigBlockMetadata meta;
    if (!GetBigBlockMetadata(userPtr, meta)) {
        std::cerr << "[MemoryPool] 释放时未找到块元数据: " << userPtr << std::endl;
        return false;
    }

    if (meta.wasFreed) {
        std::cerr << "[MemoryPool] 检测到二次释放: " << userPtr << std::endl;
        return true;  // 返回成功，避免崩溃
    }

    // 【标记为已释放】
    {
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        auto it = m_bigBlockMetadata.find(userPtr);
        if (it != m_bigBlockMetadata.end()) {
            it->second.wasFreed = true;
        }
    }

    std::cout << "[MemoryPool] 释放VirtualAlloc大块详细: userPtr=" << userPtr
        << " metaPtr=" << meta.metaPtr << " totalSize=" << meta.totalAllocSize << std::endl;

    // 【VirtualFree释放】
    bool freeSuccess = VirtualFreeBigBlock(userPtr);

    if (freeSuccess) {
        // 【清理元数据】
        UnregisterBigBlock(userPtr);

        // 【统计更新】
        m_stats.bigBlocksFreed.fetch_add(1, std::memory_order_relaxed);
        m_stats.currentBigBlockUsage.fetch_sub(meta.totalAllocSize, std::memory_order_relaxed);

        std::cout << "[MemoryPool] VirtualAlloc大块释放成功: " << userPtr << std::endl;
    }
    else {
        std::cerr << "[MemoryPool] VirtualFree失败: " << userPtr << std::endl;

        // 【恢复元数据状态】
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        auto it = m_bigBlockMetadata.find(userPtr);
        if (it != m_bigBlockMetadata.end()) {
            it->second.wasFreed = false;
        }
    }

    return freeSuccess;
}

/**
 * 【核心修复】重新分配大块内存 - VirtualAlloc版本
 */
void* StormCompatibleMemoryPool::ReallocateBigBlock(void* oldPtr, size_t newSize,
    const char* filename, uint32_t line)
{
    if (!oldPtr) {
        return AllocateBigBlock(newSize, filename, line);
    }

    if (newSize == 0) {
        FreeBigBlock(oldPtr, filename, line);
        return nullptr;
    }

    if (newSize < m_bigBlockThreshold) {
        std::cerr << "[MemoryPool] ReAlloc目标不是大块: " << newSize << std::endl;
        return nullptr;  // 让调用者处理混合realloc
    }

    // 【获取旧块大小】
    size_t oldSize = GetBigBlockSize(oldPtr);
    if (oldSize == 0) {
        std::cerr << "[MemoryPool] 无法获取旧块大小: " << oldPtr << std::endl;
        return nullptr;
    }

    std::cout << "[MemoryPool] 重分配VirtualAlloc大块: " << oldPtr
        << " " << (oldSize / 1024) << "KB -> " << (newSize / 1024) << "KB" << std::endl;

    // 【简单策略：分配新块，复制数据，释放旧块】
    void* newPtr = AllocateBigBlock(newSize, filename, line);
    if (!newPtr) {
        std::cerr << "[MemoryPool] 重分配时新块分配失败" << std::endl;
        return nullptr;
    }

    // 【复制数据】
    size_t copySize = (newSize < oldSize) ? newSize : oldSize;
    memcpy(newPtr, oldPtr, copySize);

    // 【释放旧块】
    FreeBigBlock(oldPtr, filename, line);

    std::cout << "[MemoryPool] VirtualAlloc大块重分配成功: " << oldPtr << " -> " << newPtr << std::endl;
    return newPtr;
}

/**
 * 【查询函数】检查是否是我们管理的大块
 */
bool StormCompatibleMemoryPool::IsOurBigBlock(void* ptr) const
{
    if (!ptr) return false;

    // 1. 首先检查元数据
    {
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        auto it = m_bigBlockMetadata.find(ptr);
        if (it != m_bigBlockMetadata.end()) {
            return !it->second.wasFreed;  // 只有未释放的才算我们的块
        }
    }

    // 2. 如果元数据中没有，尝试验证Storm头部
    return ValidateBigBlock(ptr);
}

size_t StormCompatibleMemoryPool::GetBigBlockSize(void* userPtr) const
{
    if (!userPtr) return 0;

    // 1. 先从元数据获取
    {
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        auto it = m_bigBlockMetadata.find(userPtr);
        if (it != m_bigBlockMetadata.end()) {
            return it->second.userSize;
        }
    }

    // 2. 从Storm头部获取
    return GetBigBlockUserSize(userPtr);
}

bool StormCompatibleMemoryPool::ValidateBigBlock(void* ptr) const
{
    return ValidateStormBigBlock(ptr);
}

/**
 * 【关键实现】VirtualAlloc大块分配
 */
void* StormCompatibleMemoryPool::VirtualAllocBigBlock(size_t userSize)
{
    // 1. 计算需要分配的总大小（包含元数据和头部）
    size_t totalSize = CalculateTotalAllocSize(userSize);

    std::cout << "[VirtualAlloc] 分配大块: userSize=" << userSize
        << " totalSize=" << totalSize << " 字节" << std::endl;

    // 2. VirtualAlloc分配内存
    void* metaPtr = VirtualAlloc(nullptr, totalSize,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!metaPtr) {
        DWORD error = GetLastError();
        std::cerr << "[VirtualAlloc] 分配失败，大小: " << totalSize
            << ", 错误: " << error << std::endl;
        return nullptr;
    }

    // 3. 设置Storm兼容头部
    void* userPtr = SetupStormBigBlockHeader(metaPtr, userSize);
    if (!userPtr) {
        std::cerr << "[VirtualAlloc] 头部设置失败" << std::endl;
        VirtualFree(metaPtr, 0, MEM_RELEASE);
        return nullptr;
    }

    // 4. 验证设置的头部
    if (!ValidateStormBigBlock(userPtr)) {
        std::cerr << "[VirtualAlloc] 头部验证失败" << std::endl;
        VirtualFree(metaPtr, 0, MEM_RELEASE);
        return nullptr;
    }

    // 5. 更新统计
    m_stats.virtualAllocCalls.fetch_add(1, std::memory_order_relaxed);
    m_stats.virtualAllocBytes.fetch_add(totalSize, std::memory_order_relaxed);

    std::cout << "[VirtualAlloc] 大块分配成功: metaPtr=" << metaPtr
        << " userPtr=" << userPtr << std::endl;

    return userPtr;
}

/**
 * 【关键实现】VirtualFree大块释放
 */
bool StormCompatibleMemoryPool::VirtualFreeBigBlock(void* userPtr)
{
    if (!userPtr) return false;

    // 1. 获取metaPtr
    void* metaPtr = GetMetaPtrFromBigBlock(userPtr);
    if (!metaPtr) {
        std::cerr << "[VirtualFree] 无法获取metaPtr: " << userPtr << std::endl;
        return false;
    }

    std::cout << "[VirtualFree] 释放大块: userPtr=" << userPtr
        << " metaPtr=" << metaPtr << std::endl;

    // 2. VirtualFree释放
    BOOL result = VirtualFree(metaPtr, 0, MEM_RELEASE);
    if (!result) {
        DWORD error = GetLastError();
        std::cerr << "[VirtualFree] 释放失败: " << metaPtr
            << ", 错误: " << error << std::endl;
        return false;
    }

    std::cout << "[VirtualFree] 大块释放成功: " << metaPtr << std::endl;
    return true;
}

void StormCompatibleMemoryPool::CleanupPool()
{
    std::cout << "[MemoryPool] 清理VirtualAlloc大块内存池..." << std::endl;

    PrintStats();

    // VirtualAlloc模式清理：检查是否有未释放的块
    {
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        if (!m_bigBlockMetadata.empty()) {
            std::cerr << "[MemoryPool] 检测到 " << m_bigBlockMetadata.size()
                << " 个VirtualAlloc大块内存泄漏" << std::endl;

            for (const auto& pair : m_bigBlockMetadata) {
                const auto& meta = pair.second;
                if (!meta.wasFreed) {
                    std::cerr << "  泄漏块: " << pair.first
                        << " 大小: " << meta.userSize
                        << " metaPtr: " << meta.metaPtr
                        << " 文件: " << (meta.sourceFile ? meta.sourceFile : "unknown")
                        << ":" << meta.sourceLine << std::endl;
                }
            }
        }
    }

    std::cout << "[MemoryPool] VirtualAlloc大块内存池清理完成" << std::endl;
}

void StormCompatibleMemoryPool::PrintStats() const
{
    std::cout << "\n=== VirtualAlloc大块模式内存池统计 ===" << std::endl;
    std::cout << "大块分配总数: " << m_stats.bigBlocksAllocated.load() << std::endl;
    std::cout << "大块释放总数: " << m_stats.bigBlocksFreed.load() << std::endl;
    std::cout << "Fallback分配数: " << m_stats.fallbackAllocs.load() << std::endl;
    std::cout << "VirtualAlloc调用: " << m_stats.virtualAllocCalls.load() << std::endl;
    std::cout << "VirtualAlloc字节: " << (m_stats.virtualAllocBytes.load() / 1024) << " KB" << std::endl;
    std::cout << "当前大块使用: " << (m_stats.currentBigBlockUsage.load() / 1024) << " KB" << std::endl;
    std::cout << "峰值大块使用: " << (m_stats.peakBigBlockUsage.load() / 1024) << " KB" << std::endl;
    std::cout << "分配阈值: " << (m_bigBlockThreshold / 1024) << " KB" << std::endl;

    {
        std::lock_guard<std::mutex> lock(m_metadataMutex);
        std::cout << "当前跟踪大块数: " << m_bigBlockMetadata.size() << std::endl;
    }

    std::cout << "分配模式: VirtualAlloc直接分配" << std::endl;
    std::cout << "头部格式: Storm兼容14字节 + 16字节元数据" << std::endl;
    std::cout << "===================================\n" << std::endl;
}

// 【保留TLSF接口】用于将来可能的混合模式
bool StormCompatibleMemoryPool::InitializeTLSF() {
    // VirtualAlloc模式下不需要TLSF，返回true表示"初始化成功"
    return true;
}

void StormCompatibleMemoryPool::ShutdownTLSF() {
    std::cout << "[MemoryPool] 关闭VirtualAlloc大块模式..." << std::endl;
    PrintStats();

    // 清理元数据
    {
        std::lock_guard<std::mutex> metaLock(m_metadataMutex);
        if (!m_bigBlockMetadata.empty()) {
            std::cerr << "[MemoryPool] 检测到 " << m_bigBlockMetadata.size()
                << " 个大块内存泄漏" << std::endl;

            for (const auto& pair : m_bigBlockMetadata) {
                const auto& meta = pair.second;
                std::cerr << "  泄漏块: " << pair.first
                    << " 大小: " << meta.userSize
                    << " 文件: " << (meta.sourceFile ? meta.sourceFile : "unknown")
                    << ":" << meta.sourceLine << std::endl;
            }

            m_bigBlockMetadata.clear();
        }
    }

    std::cout << "[MemoryPool] VirtualAlloc大块模式已关闭" << std::endl;
}

void* StormCompatibleMemoryPool::TLSFAllocateAligned(size_t size) {
    // VirtualAlloc模式下不使用TLSF
    return nullptr;
}

void StormCompatibleMemoryPool::TLSFFreeSafe(void* ptr) {
    // VirtualAlloc模式下不使用TLSF
}

void StormCompatibleMemoryPool::RegisterBigBlock(void* userPtr, const BigBlockMetadata& metadata)
{
    std::lock_guard<std::mutex> lock(m_metadataMutex);
    m_bigBlockMetadata[userPtr] = metadata;
}

bool StormCompatibleMemoryPool::UnregisterBigBlock(void* userPtr)
{
    std::lock_guard<std::mutex> lock(m_metadataMutex);
    auto it = m_bigBlockMetadata.find(userPtr);
    if (it != m_bigBlockMetadata.end()) {
        m_bigBlockMetadata.erase(it);
        return true;
    }
    return false;
}

bool StormCompatibleMemoryPool::GetBigBlockMetadata(void* userPtr, BigBlockMetadata& metadata) const
{
    std::lock_guard<std::mutex> lock(m_metadataMutex);
    auto it = m_bigBlockMetadata.find(userPtr);
    if (it != m_bigBlockMetadata.end()) {
        metadata = it->second;
        return true;
    }
    return false;
}

size_t StormCompatibleMemoryPool::GetTLSFUsage() const
{
    return 0;  // VirtualAlloc模式下没有TLSF池
}

size_t StormCompatibleMemoryPool::GetTLSFSize() const
{
    return 0;  // VirtualAlloc模式下没有TLSF池
}

bool StormCompatibleMemoryPool::CheckTLSFIntegrity()
{
    return true;  // VirtualAlloc模式下总是通过
}

/**
 * 【调试函数】输出大块的详细信息（修复版）
 */
void StormCompatibleMemoryPool::DebugDumpBigBlock(void* userPtr)
{
    if (!userPtr) {
        std::cout << "[Debug] userPtr 为空" << std::endl;
        return;
    }

    std::cout << "[Debug] ======== VirtualAlloc大块信息 ========" << std::endl;
    std::cout << "[Debug] userPtr: " << userPtr << std::endl;

    // 1. 检查元数据
    BigBlockMetadata meta;
    bool hasMeta = GetBigBlockMetadata(userPtr, meta);
    if (hasMeta) {
        std::cout << "[Debug] === 内部元数据 ===" << std::endl;
        std::cout << "[Debug] metaPtr: " << meta.metaPtr << std::endl;
        std::cout << "[Debug] userSize: " << meta.userSize << std::endl;
        std::cout << "[Debug] totalAllocSize: " << meta.totalAllocSize << std::endl;
        std::cout << "[Debug] sourceFile: " << (meta.sourceFile ? meta.sourceFile : "null") << std::endl;
        std::cout << "[Debug] sourceLine: " << meta.sourceLine << std::endl;
        std::cout << "[Debug] wasFreed: " << (meta.wasFreed ? "是" : "否") << std::endl;
    }
    else {
        std::cout << "[Debug] ❌ 未找到内部元数据" << std::endl;
    }

    // 2. 检查Storm头部和外部元数据
    __try {
        auto* header = GetHeaderFromBigBlock(userPtr);
        void* metaPtr = GetMetaPtrFromBigBlock(userPtr);

        if (header && metaPtr) {
            std::cout << "[Debug] === Storm头部 ===" << std::endl;
            std::cout << "[Debug] BlockHdrSize: " << header->BlockHdrSize
                << " (期望: " << StormBigBlockConst::BLOCK_HDR_SIZE << ")" << std::endl;
            std::cout << "[Debug] AlignPad: " << (int)header->AlignPad << std::endl;
            std::cout << "[Debug] Flags: 0x" << std::hex << (int)header->Flags << std::dec;
            if ((header->Flags & StormBigBlockConst::VIRTUALALLOC_FLAG) != 0) {
                std::cout << " ✅ [包含0x04大块标志]";
            }
            else {
                std::cout << " ❌ [缺少0x04标志]";
            }
            std::cout << std::endl;

            std::cout << "[Debug] HeapStub: 0x" << std::hex << header->HeapStub << std::dec << std::endl;
            std::cout << "[Debug] MetaPtr: 0x" << std::hex << header->MetaPtr << std::dec << std::endl;
            std::cout << "[Debug] FrontMagic: 0x" << std::hex << header->FrontMagic << std::dec;
            if (header->FrontMagic == StormBigBlockConst::FRONT_MAGIC) {
                std::cout << " ✅";
            }
            else {
                std::cout << " ❌";
            }
            std::cout << std::endl;

            // 检查外部元数据
            auto* stormMeta = static_cast<StormBigBlockMeta*>(metaPtr);
            std::cout << "[Debug] === 外部元数据 ===" << std::endl;
            std::cout << "[Debug] RealUserSize: " << stormMeta->RealUserSize << std::endl;
            std::cout << "[Debug] BlockHdrSizeCopy: " << stormMeta->BlockHdrSizeCopy << std::endl;
            std::cout << "[Debug] MetaMagic: 0x" << std::hex << stormMeta->MetaMagic << std::dec;
            if (stormMeta->MetaMagic == StormBigBlockConst::META_MAGIC) {
                std::cout << " ✅";
            }
            else {
                std::cout << " ❌";
            }
            std::cout << std::endl;
        }

        // 验证结果
        bool valid = ValidateBigBlock(userPtr);
        std::cout << "[Debug] 整体验证: " << (valid ? "✅ 通过" : "❌ 失败") << std::endl;

    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        std::cout << "[Debug] ❌ 读取头部异常: 0x" << std::hex
            << GetExceptionCode() << std::dec << std::endl;
    }

    std::cout << "[Debug] ==============================" << std::endl;
}

/**
 * 【测试函数】VirtualAlloc大块分配释放压力测试
 */
bool StormCompatibleMemoryPool::RunBigBlockTest(int iterations)
{
    std::cout << "[Test] 开始VirtualAlloc大块压力测试，迭代次数: " << iterations << std::endl;

    std::vector<void*> ptrs;
    std::vector<size_t> sizes;

    // 测试不同大小的大块
    size_t testSizes[] = {
        128 * 1024,      // 128KB
        256 * 1024,      // 256KB  
        512 * 1024,      // 512KB
        1024 * 1024,     // 1MB
        2048 * 1024      // 2MB
    };

    bool allPassed = true;

    for (int i = 0; i < iterations; i++) {
        size_t testSize = testSizes[i % (sizeof(testSizes) / sizeof(testSizes[0]))];

        // 分配
        void* ptr = AllocateBigBlock(testSize, "VirtualAllocTest", i);
        if (!ptr) {
            std::cerr << "[Test] 分配失败，迭代: " << i << ", 大小: " << testSize << std::endl;
            allPassed = false;
            continue;
        }

        ptrs.push_back(ptr);
        sizes.push_back(testSize);

        // 验证
        if (!ValidateBigBlock(ptr)) {
            std::cerr << "[Test] 验证失败，迭代: " << i << ", ptr: " << ptr << std::endl;
            allPassed = false;
            DebugDumpBigBlock(ptr);
        }

        // 写入测试数据
        memset(ptr, 0xAA, testSize);

        // 每10次迭代释放一半
        if (i % 10 == 9 && ptrs.size() > 5) {
            for (size_t j = 0; j < ptrs.size() / 2; j++) {
                if (!FreeBigBlock(ptrs[j], "VirtualAllocTest", i)) {
                    std::cerr << "[Test] 释放失败，ptr: " << ptrs[j] << std::endl;
                    allPassed = false;
                }
            }
            ptrs.erase(ptrs.begin(), ptrs.begin() + ptrs.size() / 2);
            sizes.erase(sizes.begin(), sizes.begin() + sizes.size() / 2);
        }
    }

    // 释放剩余的块
    for (void* ptr : ptrs) {
        if (!FreeBigBlock(ptr, "VirtualAllocTest", 0)) {
            std::cerr << "[Test] 最终释放失败，ptr: " << ptr << std::endl;
            allPassed = false;
        }
    }

    std::cout << "[Test] VirtualAlloc大块压力测试完成，结果: " << (allPassed ? "✅ 通过" : "❌ 失败") << std::endl;
    PrintStats();

    return allPassed;
}