﻿/**
 * StormHook.cpp - 修复版本，配合VirtualAlloc大块模式
 *
 * 【核心修复】：
 * 1. 移除Size字段溢出的错误日志（已修复）
 * 2. 使用与MemoryPool一致的阈值常量
 * 3. 简化fallback逻辑（VirtualAlloc版本应该很少失败）
 * 4. 增强调试信息，显示Storm兼容头部状态
 */

#include "pch.h"
#include "StormHook.h"
#include "MemoryPool.h"
#include "StormOffsets.h"
#include <Windows.h>
#include <detours.h>
#include <iostream>
#include <mutex>
#include <unordered_set>
#include <Base/MemorySafety.h>

 // 【修复】使用与MemoryPool一致的阈值
constexpr size_t kBigBlock = StormBigBlockConst::CONSERVATIVE_MIN;  // 128KB保守阈值

// 静态成员初始化
std::unique_ptr<StormHookManager> StormHookManager::s_instance;
std::mutex StormHookManager::s_instanceMutex;

// 【修复】暴露给MemoryPool的全局原始函数指针
Storm_MemAlloc_t g_origStormAlloc = nullptr;
Storm_MemFree_t g_origStormFree = nullptr;
Storm_MemReAlloc_t g_origStormRealloc = nullptr;

// Hook控制状态
static std::atomic<bool> g_hooksEnabled{ true };
static std::atomic<bool> g_safeModeEnabled{ false };
static std::atomic<bool> g_debugModeEnabled{ false };

// 线程本地递归深度追踪
thread_local uint32_t tls_recursionDepth = 0;

// 【新增】Fallback追踪集合 - 记录通过原生Storm分配的指针
static std::mutex g_fallbackMutex;
static std::unordered_set<void*> g_fallbackSet;

// 纯C函数：验证代码有效性
static int ValidateCodePointer_C(void* ptr) {
    if (!ptr) return 0;

    __try {
        uint8_t* code = (uint8_t*)ptr;
        return (code[0] != 0x00 && code[0] != 0xFF) ? 1 : 0;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return 0;
    }
}

// 【修复】Fallback管理函数
static void AddFallbackPtr(void* ptr) {
    if (!ptr) return;
    std::lock_guard<std::mutex> lock(g_fallbackMutex);
    g_fallbackSet.insert(ptr);
}

static bool RemoveFallbackPtr(void* ptr) {
    if (!ptr) return false;
    std::lock_guard<std::mutex> lock(g_fallbackMutex);
    auto it = g_fallbackSet.find(ptr);
    if (it != g_fallbackSet.end()) {
        g_fallbackSet.erase(it);
        return true;
    }
    return false;
}

static bool IsFallbackPtr(void* ptr) {
    if (!ptr) return false;
    std::lock_guard<std::mutex> lock(g_fallbackMutex);
    return g_fallbackSet.find(ptr) != g_fallbackSet.end();
}

// 获取单例
StormHookManager& StormHookManager::GetInstance()
{
    std::lock_guard<std::mutex> lk(s_instanceMutex);
    if (!s_instance) {
        s_instance.reset(new StormHookManager);
    }
    return *s_instance;
}

bool StormHookManager::Initialize()
{
    if (m_initialized.load(std::memory_order_acquire))
        return true;

    std::cout << "[StormHook] 正在初始化Storm内存Hook (VirtualAlloc大块模式 ≥"
        << (kBigBlock / 1024) << "KB)...\n";

    // ① 先解析目标地址
    if (!FindStormFunctions()) {
        std::cerr << "[StormHook] 查找Storm函数失败" << std::endl;
        return false;
    }

    // ② 【关键】立即设置全局函数指针，供MemoryPool使用
    g_origStormAlloc = m_origStormAlloc;
    g_origStormFree = m_origStormFree;
    g_origStormRealloc = m_origStormRealloc;

    std::cout << "[StormHook] 全局原始函数指针已设置" << std::endl;

    // ③ 初始化内存池（VirtualAlloc大块模式）
    if (!StormCompatibleMemoryPool::Initialize()) {
        std::cerr << "[StormHook] 内存池初始化失败" << std::endl;
        return false;
    }

    // 设置原始函数指针给内存池
    g_MemoryPool.SetOriginalFunctions(
        reinterpret_cast<void*>(m_origStormAlloc),
        reinterpret_cast<void*>(m_origStormFree),
        reinterpret_cast<void*>(m_origStormRealloc)
    );

    // ④ 安装Hook
    if (!InstallHooks()) {
        std::cerr << "[StormHook] Hook安装失败" << std::endl;
        return false;
    }

    m_initialized.store(true, std::memory_order_release);

    std::cout << "[StormHook] Storm内存Hook初始化成功 (VirtualAlloc大块模式)" << std::endl;
    std::cout << "  - 大块阈值      : " << (kBigBlock / 1024) << " KB" << std::endl;
    std::cout << "  - 分配模式      : VirtualAlloc直接分配" << std::endl;
    std::cout << "  - 头部格式      : Storm兼容14字节 + 16字节元数据" << std::endl;
    std::cout << "  - 大块标志      : 0x" << std::hex << (int)StormBigBlockConst::BIG_BLOCK_FLAGS << std::dec << std::endl;
    std::cout << "  - 原始Alloc     : " << (void*)m_origStormAlloc << std::endl;
    std::cout << "  - 原始Free      : " << (void*)m_origStormFree << std::endl;
    std::cout << "  - 原始ReAlloc   : " << (void*)m_origStormRealloc << std::endl;

    return true;
}

void StormHookManager::Shutdown() {
    if (!m_initialized.load(std::memory_order_acquire)) {
        return;
    }

    std::cout << "\n[StormHook] 正在关闭Storm内存Hook..." << std::endl;

    PrintStats();
    UninstallHooks();

    // 清理Fallback集合
    {
        std::lock_guard<std::mutex> lock(g_fallbackMutex);
        if (!g_fallbackSet.empty()) {
            std::cout << "[StormHook] 清理 " << g_fallbackSet.size() << " 个fallback指针" << std::endl;
            g_fallbackSet.clear();
        }
    }

    // 清空全局函数指针
    g_origStormAlloc = nullptr;
    g_origStormFree = nullptr;
    g_origStormRealloc = nullptr;

    m_initialized.store(false, std::memory_order_release);
    std::cout << "[StormHook] Storm内存Hook已关闭" << std::endl;
}

bool StormHookManager::FindStormFunctions() {
    HMODULE stormDll = GetModuleHandleA("Storm.dll");
    if (!stormDll) {
        std::cerr << "[StormHook] 未找到Storm.dll模块" << std::endl;
        return false;
    }

    gStormDllBase = reinterpret_cast<uintptr_t>(stormDll);
    std::cout << "[StormHook] Storm.dll基址: 0x" << std::hex << gStormDllBase << std::dec << std::endl;

    // 根据IDA分析的正确偏移计算函数地址
    m_origStormAlloc = reinterpret_cast<Storm_MemAlloc_t>(gStormDllBase + 0x2B830);
    m_origStormFree = reinterpret_cast<Storm_MemFree_t>(gStormDllBase + 0x2BE40);
    m_origStormRealloc = reinterpret_cast<Storm_MemReAlloc_t>(gStormDllBase + 0x2C8B0);

    // 复制到Hook指针
    m_hookedStormAlloc = m_origStormAlloc;
    m_hookedStormFree = m_origStormFree;
    m_hookedStormRealloc = m_origStormRealloc;

    if (!m_origStormAlloc || !m_origStormFree || !m_origStormRealloc) {
        std::cerr << "[StormHook] 无效的函数指针" << std::endl;
        return false;
    }

    if (!ValidateCodePointer_C(m_origStormAlloc) || !ValidateCodePointer_C(m_origStormFree) ||
        !ValidateCodePointer_C(m_origStormRealloc)) {
        std::cerr << "[StormHook] 函数指针指向无效代码" << std::endl;
        return false;
    }

    std::cout << "[StormHook] Storm函数地址验证成功" << std::endl;
    return true;
}

bool StormHookManager::InstallHooks() {
    if (m_hooksInstalled.load(std::memory_order_acquire)) {
        return true;
    }

    LONG result = DetourTransactionBegin();
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] DetourTransactionBegin失败: " << result << std::endl;
        return false;
    }

    result = DetourUpdateThread(GetCurrentThread());
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] DetourUpdateThread失败: " << result << std::endl;
        DetourTransactionAbort();
        return false;
    }

    result = DetourAttach(&(PVOID&)m_hookedStormAlloc, Hooked_Storm_MemAlloc);
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 安装MemAlloc Hook失败: " << result << std::endl;
        DetourTransactionAbort();
        return false;
    }

    result = DetourAttach(&(PVOID&)m_hookedStormFree, Hooked_Storm_MemFree);
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 安装MemFree Hook失败: " << result << std::endl;
        DetourTransactionAbort();
        return false;
    }

    result = DetourAttach(&(PVOID&)m_hookedStormRealloc, Hooked_Storm_MemReAlloc);
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 安装MemReAlloc Hook失败: " << result << std::endl;
        DetourTransactionAbort();
        return false;
    }

    result = DetourTransactionCommit();
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] DetourTransactionCommit失败: " << result << std::endl;
        return false;
    }

    m_hooksInstalled.store(true, std::memory_order_release);
    std::cout << "[StormHook] Hook安装成功" << std::endl;
    return true;
}

bool StormHookManager::UninstallHooks() {
    if (!m_hooksInstalled.load(std::memory_order_acquire)) {
        return true;
    }

    LONG result = DetourTransactionBegin();
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 卸载Hook时DetourTransactionBegin失败: " << result << std::endl;
        return false;
    }

    result = DetourUpdateThread(GetCurrentThread());
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 卸载Hook时DetourUpdateThread失败: " << result << std::endl;
        DetourTransactionAbort();
        return false;
    }

    DetourDetach(&(PVOID&)m_hookedStormAlloc, Hooked_Storm_MemAlloc);
    DetourDetach(&(PVOID&)m_hookedStormFree, Hooked_Storm_MemFree);
    DetourDetach(&(PVOID&)m_hookedStormRealloc, Hooked_Storm_MemReAlloc);

    result = DetourTransactionCommit();
    if (result != NO_ERROR) {
        std::cerr << "[StormHook] 卸载Hook时DetourTransactionCommit失败: " << result << std::endl;
        return false;
    }

    m_hooksInstalled.store(false, std::memory_order_release);
    return true;
}

void StormHookManager::PrintStats() const {
    std::cout << "\n=== Storm Hook 统计信息 (VirtualAlloc大块模式) ===" << std::endl;
    std::cout << "总分配调用: " << m_stats.allocCalls.load() << std::endl;
    std::cout << "总释放调用: " << m_stats.freeCalls.load() << std::endl;
    std::cout << "总重分配调用: " << m_stats.reallocCalls.load() << std::endl;
    std::cout << "大块分配(VirtualAlloc): " << m_stats.allocToPool.load() << std::endl;
    std::cout << "小块Pass-through: " << m_stats.allocPassthrough.load() << std::endl;
    std::cout << "大块释放(VirtualFree): " << m_stats.freeFromPool.load() << std::endl;
    std::cout << "小块Pass-through释放: " << m_stats.freePassthrough.load() << std::endl;
    std::cout << "Fallback分配数: " << m_stats.fallbackAllocs.load() << std::endl;
    std::cout << "Hook状态: " << (g_hooksEnabled.load() ? "启用" : "禁用") << std::endl;
    std::cout << "安全模式: " << (g_safeModeEnabled.load() ? "启用" : "禁用") << std::endl;
    std::cout << "调试模式: " << (g_debugModeEnabled.load() ? "启用" : "禁用") << std::endl;
    std::cout << "分配阈值: " << (kBigBlock / 1024) << " KB" << std::endl;

    {
        std::lock_guard<std::mutex> lock(g_fallbackMutex);
        std::cout << "当前Fallback指针数: " << g_fallbackSet.size() << std::endl;
    }

    std::cout << "============================\n" << std::endl;
}

void StormHookManager::ResetStats() {
    m_stats.allocCalls.store(0);
    m_stats.freeCalls.store(0);
    m_stats.reallocCalls.store(0);
    m_stats.allocToPool.store(0);
    m_stats.allocPassthrough.store(0);
    m_stats.freeFromPool.store(0);
    m_stats.freePassthrough.store(0);
    m_stats.fallbackAllocs.store(0);
}

// Hook函数实现

/**
 * 【修复版】分配Hook - VirtualAlloc大块模式
 * size >= 128KB: 走MemoryPool的VirtualAlloc分配，使用Storm兼容14字节头部
 * size < 128KB:  直接调用原生Storm，完全不碰
 */
void* __fastcall Hooked_Storm_MemAlloc(
    int ecx, int edx, size_t size,
    const char* name, uint32_t src_line, uint32_t flag)
{
    // 递归保护
    if (tls_recursionDepth > 0) {
        auto& mgr = g_StormHook;
        return mgr.HookedAlloc()(ecx, edx, size, name, src_line, flag);
    }

    if (size == 0) {
        return nullptr;
    }

    ++tls_recursionDepth;

    auto& mgr = g_StormHook;
    mgr.Stats().allocCalls.fetch_add(1, std::memory_order_relaxed);

    void* result = nullptr;

    // Hook被禁用或安全模式 → 全部直通
    if (!StormHookControl::AreHooksEnabled() || StormHookControl::IsSafeModeEnabled()) {
        mgr.Stats().allocPassthrough.fetch_add(1, std::memory_order_relaxed);
        result = mgr.HookedAlloc()(ecx, edx, size, name, src_line, flag);
        if (result) {
            AddFallbackPtr(result);
        }
    }
    // 【关键判断】是否为大块
    else if (size >= kBigBlock) {
        // 大块：走MemoryPool + VirtualAlloc
        if (StormHookControl::IsDebugModeEnabled()) {
            std::cout << "[Hook] VirtualAlloc大块分配 " << (size / 1024) << " KB @"
                << (name ? name : "null") << ':' << src_line << std::endl;
        }

        try {
            result = g_MemoryPool.AllocateBigBlock(size, name, src_line);

            if (!result) {
                // 【关键Fallback】VirtualAlloc分配失败，立即使用Storm
                std::cerr << "[Hook] VirtualAlloc大块分配失败，使用Storm fallback: "
                    << (size / 1024) << " KB" << std::endl;
                result = mgr.HookedAlloc()(ecx, edx, size, name, src_line, flag);
                if (result) {
                    AddFallbackPtr(result);
                    mgr.Stats().fallbackAllocs.fetch_add(1, std::memory_order_relaxed);
                }
            }
            else {
                mgr.Stats().allocToPool.fetch_add(1, std::memory_order_relaxed);

                // 【调试】验证分配的块
                if (StormHookControl::IsDebugModeEnabled()) {
                    if (g_MemoryPool.ValidateBigBlock(result)) {
                        std::cout << "[Hook] ✅ VirtualAlloc大块验证通过: " << result << std::endl;
                    }
                    else {
                        std::cerr << "[Hook] ❌ VirtualAlloc大块验证失败: " << result << std::endl;
                        g_MemoryPool.DebugDumpBigBlock(result);
                    }
                }
            }
        }
        catch (...) {
            std::cerr << "[Hook] VirtualAlloc大块分配异常，使用Storm fallback" << std::endl;
            result = mgr.HookedAlloc()(ecx, edx, size, name, src_line, flag);
            if (result) {
                AddFallbackPtr(result);
                mgr.Stats().fallbackAllocs.fetch_add(1, std::memory_order_relaxed);
            }
        }
    }
    else {
        // 小块：直接调用原生Storm，完全不处理
        mgr.Stats().allocPassthrough.fetch_add(1, std::memory_order_relaxed);
        result = mgr.HookedAlloc()(ecx, edx, size, name, src_line, flag);

        // 【不需要】AddFallbackPtr，因为小块我们从来不管
    }

    --tls_recursionDepth;
    return result;
}

/**
 * 【修复版】释放Hook - VirtualAlloc大块模式
 * 检查是否是我们的VirtualAlloc大块 → 走MemoryPool释放
 * 否则直接调用原生Storm
 */
int __stdcall Hooked_Storm_MemFree(void* ptr, const char* name,
    uint32_t src_line, uint32_t flag) {

    if (tls_recursionDepth > 0) {
        auto& mgr = g_StormHook;
        return mgr.HookedFree()(ptr, name, src_line, flag);
    }

    ++tls_recursionDepth;

    auto& hookMgr = g_StormHook;
    hookMgr.Stats().freeCalls.fetch_add(1, std::memory_order_relaxed);

    int result = 0;

    if (!ptr) {
        result = 1;
    }
    else if (!StormHookControl::AreHooksEnabled()) {
        hookMgr.Stats().freePassthrough.fetch_add(1, std::memory_order_relaxed);
        result = hookMgr.HookedFree()(ptr, name, src_line, flag);
    }
    else {
        // 【关键判断】是否是我们管理的VirtualAlloc大块
        bool isOurBigBlock = g_MemoryPool.IsOurBigBlock(ptr);
        bool isFallbackPtr = RemoveFallbackPtr(ptr);

        if (isOurBigBlock) {
            // 我们的VirtualAlloc大块 → 走MemoryPool释放
            if (StormHookControl::IsDebugModeEnabled()) {
                std::cout << "[Hook] 释放VirtualAlloc大块: " << ptr << std::endl;
            }

            try {
                bool success = g_MemoryPool.FreeBigBlock(ptr, name, src_line);
                hookMgr.Stats().freeFromPool.fetch_add(1, std::memory_order_relaxed);
                result = success ? 1 : 0;
            }
            catch (...) {
                std::cerr << "[Hook] VirtualAlloc大块释放异常，使用Storm fallback: " << ptr << std::endl;
                result = hookMgr.HookedFree()(ptr, name, src_line, flag);
                hookMgr.Stats().freePassthrough.fetch_add(1, std::memory_order_relaxed);
            }
        }
        else {
            // 不是我们的块（小块或fallback）→ 直接调用原生Storm
            hookMgr.Stats().freePassthrough.fetch_add(1, std::memory_order_relaxed);
            result = hookMgr.HookedFree()(ptr, name, src_line, flag);
        }
    }

    --tls_recursionDepth;
    return result;
}

/**
 * 【修复版】重分配Hook - VirtualAlloc大块模式
 * 根据oldPtr和newSize决定处理方式
 */
void* __fastcall Hooked_Storm_MemReAlloc(
    int ecx, int edx, void* oldPtr, size_t newSize,
    const char* name, uint32_t src_line, uint32_t flag)
{
    // Storm内部特殊标记，直接回退
    if (newSize & 0x80000000U) {
        auto& mgr = g_StormHook;
        return mgr.HookedReAlloc()(ecx, edx, oldPtr, newSize, name, src_line, flag);
    }

    if (tls_recursionDepth > 0) {
        auto& mgr = g_StormHook;
        return mgr.HookedReAlloc()(ecx, edx, oldPtr, newSize, name, src_line, flag);
    }

    ++tls_recursionDepth;

    auto& hookMgr = g_StormHook;
    hookMgr.Stats().reallocCalls.fetch_add(1, std::memory_order_relaxed);

    void* result = nullptr;

    if (!StormHookControl::AreHooksEnabled() || StormHookControl::IsSafeModeEnabled()) {
        // Hook禁用，直通Storm
        result = hookMgr.HookedReAlloc()(ecx, edx, oldPtr, newSize, name, src_line, flag);
    }
    else {
        // 【VirtualAlloc大块模式ReAlloc策略】
        bool oldIsBigBlock = oldPtr && g_MemoryPool.IsOurBigBlock(oldPtr);
        bool newIsBigBlock = (newSize >= kBigBlock);

        //if (StormHookControl::IsDebugModeEnabled()) {
        //    std::cout << "[Hook] ReAlloc: oldPtr=" << oldPtr
        //        << " oldIsBig=" << oldIsBigBlock
        //        << " newSize=" << (newSize / 1024) << "KB"
        //        << " newIsBig=" << newIsBigBlock << std::endl;
        //}

        if (oldIsBigBlock && newIsBigBlock) {
            // VirtualAlloc大块 → VirtualAlloc大块：尝试MemoryPool处理
            try {
                result = g_MemoryPool.ReallocateBigBlock(oldPtr, newSize, name, src_line);
                if (!result) {
                    // fallback到手动复制
                    std::cerr << "[Hook] VirtualAlloc ReAlloc失败，手动复制" << std::endl;
                    void* newPtr = g_MemoryPool.AllocateBigBlock(newSize, name, src_line);
                    if (newPtr && oldPtr) {
                        size_t oldSize = g_MemoryPool.GetBigBlockSize(oldPtr);
                        size_t copySize = (newSize < oldSize) ? newSize : oldSize;
                        memcpy(newPtr, oldPtr, copySize);
                        g_MemoryPool.FreeBigBlock(oldPtr, name, src_line);
                    }
                    result = newPtr;
                }
            }
            catch (...) {
                std::cerr << "[Hook] VirtualAlloc大块ReAlloc异常，回退Storm" << std::endl;
                result = hookMgr.HookedReAlloc()(ecx, edx, oldPtr, newSize, name, src_line, flag);
            }
        }
        else if (oldIsBigBlock && !newIsBigBlock) {
            // VirtualAlloc大块 → 小块：释放大块，分配小块
            void* newPtr = hookMgr.HookedAlloc()(0, 0, newSize, name, src_line, flag);
            if (newPtr && oldPtr) {
                size_t oldSize = g_MemoryPool.GetBigBlockSize(oldPtr);
                size_t copySize = (newSize < oldSize) ? newSize : oldSize;
                memcpy(newPtr, oldPtr, copySize);
                g_MemoryPool.FreeBigBlock(oldPtr, name, src_line);
            }
            result = newPtr;
        }
        else if (!oldIsBigBlock && newIsBigBlock) {
            // 小块 → VirtualAlloc大块：分配大块，释放小块
            void* newPtr = g_MemoryPool.AllocateBigBlock(newSize, name, src_line);
            if (newPtr && oldPtr) {
                // 估算小块大小（不精确，但安全）
                size_t copySize = (newSize < 1024) ? newSize : 1024;
                memcpy(newPtr, oldPtr, copySize);
                hookMgr.HookedFree()(oldPtr, name, src_line, flag);
            }
            result = newPtr;
        }
        else {
            // 小块 → 小块：直接调用Storm
            result = hookMgr.HookedReAlloc()(ecx, edx, oldPtr, newSize, name, src_line, flag);
        }
    }

    --tls_recursionDepth;
    return result;
}

// 全局初始化和关闭接口
bool InitializeStormHooks() {
    return g_StormHook.Initialize();
}

void ShutdownStormHooks() {
    g_StormHook.Shutdown();
}

// Hook控制实现
namespace StormHookControl {

    void DisableHooks() {
        g_hooksEnabled.store(false, std::memory_order_release);
        std::cout << "[StormHook] Hook已禁用" << std::endl;
    }

    void EnableHooks() {
        g_hooksEnabled.store(true, std::memory_order_release);
        std::cout << "[StormHook] Hook已启用" << std::endl;
    }

    bool AreHooksEnabled() {
        return g_hooksEnabled.load(std::memory_order_acquire);
    }

    void EnableSafeMode() {
        g_safeModeEnabled.store(true, std::memory_order_release);
        std::cout << "[StormHook] 安全模式已启用（所有分配都将pass-through）" << std::endl;
    }

    void DisableSafeMode() {
        g_safeModeEnabled.store(false, std::memory_order_release);
        std::cout << "[StormHook] 安全模式已禁用" << std::endl;
    }

    bool IsSafeModeEnabled() {
        return g_safeModeEnabled.load(std::memory_order_acquire);
    }

    void EnableDebugMode() {
        g_debugModeEnabled.store(true, std::memory_order_release);
        std::cout << "[StormHook] 调试模式已启用" << std::endl;
    }

    void DisableDebugMode() {
        g_debugModeEnabled.store(false, std::memory_order_release);
        std::cout << "[StormHook] 调试模式已禁用" << std::endl;
    }

    bool IsDebugModeEnabled() {
        return g_debugModeEnabled.load(std::memory_order_acquire);
    }
}