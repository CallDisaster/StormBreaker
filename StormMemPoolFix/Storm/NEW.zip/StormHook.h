﻿/**
 * StormHook.h - 大块模式版本的Storm内存函数钩子
 *
 * 【核心变化】：
 * 1. 移除CleanupAll相关功能（大块模式不需要）
 * 2. 添加fallbackAllocs统计
 * 3. 简化Hook管理逻辑
 */
#pragma once
#include <cstdint>
#include <cstddef>
#include <atomic>
#include <memory>
#include <mutex>

 // Storm函数类型定义
typedef void* (__fastcall* Storm_MemAlloc_t)(int ecx, int edx, size_t size,
    const char* name, uint32_t src_line, uint32_t flag);
typedef int(__stdcall* Storm_MemFree_t)(void* ptr, const char* name,
    uint32_t src_line, uint32_t flag);
typedef void* (__fastcall* Storm_MemReAlloc_t)(int ecx, int edx, void* oldPtr, size_t newSize,
    const char* name, uint32_t src_line, uint32_t flag);

// 【修复】全局原始函数指针声明
extern Storm_MemAlloc_t g_origStormAlloc;
extern Storm_MemFree_t g_origStormFree;
extern Storm_MemReAlloc_t g_origStormRealloc;

// --- 单例管理器（大块模式版本） ---
class StormHookManager {
public:
    StormHookManager() = default;
    ~StormHookManager() = default;
    StormHookManager(const StormHookManager&) = delete;
    StormHookManager& operator=(const StormHookManager&) = delete;

    /* 单例访问 */
    static StormHookManager& GetInstance();

    bool Initialize();
    void Shutdown();
    bool IsInitialized() const { return m_initialized.load(std::memory_order_acquire); }

    /* Hook后的函数指针 getters（用于Detours） */
    Storm_MemAlloc_t     HookedAlloc()      const { return m_hookedStormAlloc; }
    Storm_MemFree_t      HookedFree()       const { return m_hookedStormFree; }
    Storm_MemReAlloc_t   HookedReAlloc()    const { return m_hookedStormRealloc; }

    /* 真正的原始函数指针 getters（避免递归调用） */
    Storm_MemAlloc_t     OrigAlloc()      const { return m_origStormAlloc; }
    Storm_MemFree_t      OrigFree()       const { return m_origStormFree; }
    Storm_MemReAlloc_t   OrigReAlloc()    const { return m_origStormRealloc; }

    // --- Hook 统计结构（大块模式版本） ---
    struct HookStats {
        std::atomic<uint64_t> allocCalls{ 0 }, freeCalls{ 0 }, reallocCalls{ 0 };
        std::atomic<uint64_t> allocToPool{ 0 }, allocPassthrough{ 0 };
        std::atomic<uint64_t> freeFromPool{ 0 }, freePassthrough{ 0 };
        std::atomic<uint64_t> fallbackAllocs{ 0 };  // 【新增】TLSF失败后fallback到Storm的次数
    };

    /* 统计 */
    HookStats& Stats() { return m_stats; }
    const HookStats& Stats() const { return m_stats; }
    void PrintStats() const;
    void ResetStats();

private:
    bool FindStormFunctions();
    bool InstallHooks();
    bool UninstallHooks();

    std::atomic<bool> m_initialized{ false };
    std::atomic<bool> m_hooksInstalled{ false };
    HookStats         m_stats;

    /* Hook后的函数指针（用于Detours安装） */
    Storm_MemAlloc_t       m_hookedStormAlloc = nullptr;
    Storm_MemFree_t        m_hookedStormFree = nullptr;
    Storm_MemReAlloc_t     m_hookedStormRealloc = nullptr;

    /* 真正的原始函数指针（避免递归调用） */
    Storm_MemAlloc_t       m_origStormAlloc = nullptr;
    Storm_MemFree_t        m_origStormFree = nullptr;
    Storm_MemReAlloc_t     m_origStormRealloc = nullptr;

    static std::unique_ptr<StormHookManager> s_instance;
    static std::mutex  s_instanceMutex;
};

// Hook函数声明
extern "C" {
    // 分配内存Hook
    void* __fastcall Hooked_Storm_MemAlloc(int ecx, int edx, size_t size,
        const char* name, uint32_t src_line, uint32_t flag);

    // 释放内存Hook
    int __stdcall Hooked_Storm_MemFree(void* ptr, const char* name,
        uint32_t src_line, uint32_t flag);

    // 重新分配内存Hook
    void* __fastcall Hooked_Storm_MemReAlloc(int ecx, int edx, void* oldPtr, size_t newSize,
        const char* name, uint32_t src_line, uint32_t flag);
}

// 便捷访问宏
#define g_StormHook StormHookManager::GetInstance()

// 全局变量声明
extern uintptr_t gStormDllBase;

// 初始化和关闭接口
extern "C" {
    bool InitializeStormHooks();
    void ShutdownStormHooks();
}

// Hook控制
namespace StormHookControl {
    // 临时禁用Hook（用于特殊情况）
    void DisableHooks();
    void EnableHooks();
    bool AreHooksEnabled();

    // 强制所有分配都pass-through给Storm（安全模式）
    void EnableSafeMode();
    void DisableSafeMode();
    bool IsSafeModeEnabled();

    // 调试模式控制
    void EnableDebugMode();
    void DisableDebugMode();
    bool IsDebugModeEnabled();
}