﻿//=== StormCompatible.cpp ===
#include "pch.h"
#include "StormCompatible.h"
#include <cstring>
#include <algorithm>
#include "StormOffsets.h"
using namespace StormCompatConfig;

namespace StormCompatible {

    // SimulatedStormHeap 实现
    SimulatedStormHeap::SimulatedStormHeap(DWORD index, const char* heapName)
        : next(nullptr), heapIndex(index), heapId(index), activeFlag(1)
        , allocCount(0), allocSize(0), fragCount(0)
        , commitGranularity(4096), commitSize(0), totalSize(StormCompatConfig::DEFAULT_HEAP_SIZE)
        , bigBlockSize(0), reallocCount(0), freeCount(0), reallocSizeCount(0)
        , srcLine(0) {

        // 计算堆签名（模拟Storm的做法）
        heapSignature = (static_cast<DWORD>(reinterpret_cast<uintptr_t>(this) >> 16) << 16) | 0x6F6D;

        // 分配连续内存区域
        memoryStart = VirtualAlloc(nullptr, DEFAULT_HEAP_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
        if (!memoryStart) {
            throw std::runtime_error("Failed to allocate simulated Storm heap memory");
        }

        memoryEnd = static_cast<char*>(memoryStart) + DEFAULT_HEAP_SIZE;
        commitSize = DEFAULT_HEAP_SIZE;

        // 初始化空闲链表
        memset(freeList, 0, sizeof(freeList));

        // 创建初始大空闲块
        StormFreeBlock* initialBlock = static_cast<StormFreeBlock*>(memoryStart);
        initialBlock->size = static_cast<WORD>(DEFAULT_HEAP_SIZE);
        initialBlock->alignPadding = 0;
        initialBlock->flags = 0x2; // 标记为空闲
        initialBlock->next = nullptr;

        // 添加到最大的空闲链表中
        freeList[8] = initialBlock;

        // 设置名称
        if (heapName) {
            strncpy_s(name, heapName, sizeof(name) - 1);
        }
        else {
            sprintf_s(name, "SimHeap_%u", index);
        }
    }

    SimulatedStormHeap::~SimulatedStormHeap() {
        if (memoryStart) {
            VirtualFree(memoryStart, 0, MEM_RELEASE);
        }
    }

    // StormCompatibleAllocator 实现
    StormCompatibleAllocator::StormCompatibleAllocator() {
        // 初始化临界区
        for (size_t i = 0; i < MAX_HEAPS; i++) {
            InitializeCriticalSection(&criticalSections_[i]);
        }
    }

    StormCompatibleAllocator::~StormCompatibleAllocator() {
        Shutdown();

        // 清理临界区
        for (size_t i = 0; i < MAX_HEAPS; i++) {
            DeleteCriticalSection(&criticalSections_[i]);
        }
    }

    StormCompatibleAllocator& StormCompatibleAllocator::GetInstance() {
        static StormCompatibleAllocator instance;
        return instance;
    }

    bool StormCompatibleAllocator::Initialize() {
        if (initialized_.exchange(true)) {
            return true; // 已经初始化
        }

        // 初始化堆表
        for (auto& heap : heapTable_) {
            heap.reset();
        }

        printf("[StormCompatible] 初始化完成\n");
        return true;
    }

    void StormCompatibleAllocator::Shutdown() {
        if (!initialized_.exchange(false)) {
            return; // 未初始化
        }

        std::lock_guard<std::mutex> lock(heapTableMutex_);

        // 清理所有堆
        for (auto& heap : heapTable_) {
            heap.reset();
        }

        printf("[StormCompatible] 关闭完成\n");
    }

    void* StormCompatibleAllocator::AllocateCompatible(size_t size, const char* name, DWORD srcLine, DWORD flags) {
        if (size == 0) return nullptr;
        if (size > 0x7FFFFFFF) return nullptr; // Storm的大小限制

        // 计算堆索引
        BYTE heapIndex = ComputeHeapIndex(name, srcLine);

        // 获取或创建堆
        SimulatedStormHeap* heap = GetOrCreateHeap(heapIndex, name);
        if (!heap) return nullptr;

        // 进入临界区
        EnterCriticalSection(&criticalSections_[heapIndex]);

        void* result = nullptr;
        __try {
            result = AllocateFromHeap(heap, size, flags);
        }
        __finally {
            LeaveCriticalSection(&criticalSections_[heapIndex]);
        }

        if (result) {
            totalAllocated_.fetch_add(size);
            allocCount_.fetch_add(1);
        }

        return result;
    }

    bool StormCompatibleAllocator::FreeCompatible(void* userPtr) {
        if (!userPtr) return true;

        // 获取块头
        StormBlockHeader* header = StormBlockHeader::FromUserPtr(userPtr);
        if (!ValidateBlockHeader(header)) {
            return false; // 不是我们管理的内存
        }

        // 获取堆指针
        SimulatedStormHeap* heap = reinterpret_cast<SimulatedStormHeap*>(header->HeapPtr);

        // 验证堆的有效性
        if (!heap || !heap->ContainsPointer(header)) {
            return false;
        }

        // 计算堆索引
        BYTE heapIndex = static_cast<BYTE>(heap->heapIndex);

        // 进入临界区
        EnterCriticalSection(&criticalSections_[heapIndex]);

        bool result = false;
        __try {
            result = FreeToHeap(heap, header);
        }
        __finally {
            LeaveCriticalSection(&criticalSections_[heapIndex]);
        }

        if (result) {
            totalFreed_.fetch_add(header->Size);
            freeCount_.fetch_add(1);
        }

        return result;
    }

    void* StormCompatibleAllocator::ReallocateCompatible(void* oldPtr, size_t newSize, const char* name, DWORD srcLine, DWORD flags) {
        if (!oldPtr) {
            return AllocateCompatible(newSize, name, srcLine, flags);
        }

        if (newSize == 0) {
            FreeCompatible(oldPtr);
            return nullptr;
        }

        // 获取旧块头
        StormBlockHeader* oldHeader = StormBlockHeader::FromUserPtr(oldPtr);
        if (!ValidateBlockHeader(oldHeader)) {
            return nullptr; // 不是我们管理的内存
        }

        size_t oldSize = oldHeader->Size;

        // 如果新大小不超过原大小的1.5倍且在同一个级别，就地调整
        if (newSize <= oldSize && newSize >= oldSize / 2) {
            oldHeader->Size = static_cast<DWORD>(newSize);
            return oldPtr;
        }

        // 分配新内存
        void* newPtr = AllocateCompatible(newSize, name, srcLine, flags);
        if (!newPtr) {
            return nullptr;
        }

        // 复制数据
        size_t copySize = (oldSize < newSize) ? oldSize : newSize;
        memcpy(newPtr, oldPtr, copySize);

        // 释放旧内存
        FreeCompatible(oldPtr);

        return newPtr;
    }

    bool StormCompatibleAllocator::IsOurPointer(void* ptr) {
        if (!ptr) return false;

        StormBlockHeader* header = StormBlockHeader::FromUserPtr(ptr);
        return ValidateBlockHeader(header);
    }

    void StormCompatibleAllocator::GetStatistics(size_t& allocated, size_t& freed, size_t& allocCount, size_t& freeCount) const {
        allocated = totalAllocated_.load();
        freed = totalFreed_.load();
        allocCount = allocCount_.load();
        freeCount = freeCount_.load();
    }

    // 私有方法实现
    SimulatedStormHeap* StormCompatibleAllocator::GetOrCreateHeap(BYTE heapIndex, const char* name) {
        // 快速路径：如果堆已存在
        if (heapTable_[heapIndex]) {
            return heapTable_[heapIndex].get();
        }

        // 慢速路径：需要创建新堆
        std::lock_guard<std::mutex> lock(heapTableMutex_);

        // 双重检查
        if (heapTable_[heapIndex]) {
            return heapTable_[heapIndex].get();
        }

        // 创建新堆
        try {
            heapTable_[heapIndex] = std::make_unique<SimulatedStormHeap>(heapIndex, name);
            return heapTable_[heapIndex].get();
        }
        catch (const std::exception& e) {
            printf("[StormCompatible] 创建堆失败: %s\n", e.what());
            return nullptr;
        }
    }

    BYTE StormCompatibleAllocator::ComputeHeapIndex(const char* name, DWORD srcLine) {
        uint32_t hash = ComputeStormHash(name, false, srcLine);
        return static_cast<BYTE>(hash & 0xFF);
    }

    void* StormCompatibleAllocator::AllocateFromHeap(SimulatedStormHeap* heap, size_t size, DWORD flags) {
        // 计算总大小（包含头部和对齐）
        size_t totalSize = sizeof(StormBlockHeader) + size;

        // 处理边界检查
        if (flags & 0x1) {
            totalSize += 2; // 边界魔数
        }

        // 8字节对齐
        totalSize = (totalSize + 7) & ~7;

        // 查找合适的空闲块
        StormFreeBlock* freeBlock = FindFreeBlock(heap, totalSize);
        if (!freeBlock) {
            return nullptr; // 无可用内存
        }

        // 从空闲链表中移除
        RemoveFromFreeList(heap, freeBlock);

        // 如果块太大，分割它
        if (freeBlock->size >= totalSize + sizeof(StormFreeBlock) + 16) {
            // 创建新的空闲块
            StormFreeBlock* newFreeBlock = reinterpret_cast<StormFreeBlock*>(
                reinterpret_cast<char*>(freeBlock) + totalSize);

            newFreeBlock->size = freeBlock->size - static_cast<WORD>(totalSize);
            newFreeBlock->alignPadding = 0;
            newFreeBlock->flags = 0x2; // 空闲标志
            newFreeBlock->next = nullptr;

            // 添加到空闲链表
            AddToFreeList(heap, newFreeBlock);

            // 更新当前块大小
            freeBlock->size = static_cast<WORD>(totalSize);
        }

        // 设置块头
        StormBlockHeader* header = reinterpret_cast<StormBlockHeader*>(freeBlock);
        SetupBlockHeader(header, heap, size, flags);

        // 更新堆统计
        heap->allocCount++;
        heap->allocSize += static_cast<DWORD>(size);

        // 返回用户数据指针
        void* userPtr = header->GetUserData();

        // 清零或填充
        if (flags & 8) {
            memset(userPtr, 0, size);
        }

        return userPtr;
    }

    bool StormCompatibleAllocator::FreeToHeap(SimulatedStormHeap* heap, StormBlockHeader* header) {
        // 验证块头
        if (header->IsFree()) {
            return false; // 双重释放
        }

        size_t userSize = header->Size;

        // 转换为空闲块
        StormFreeBlock* freeBlock = reinterpret_cast<StormFreeBlock*>(header);
        freeBlock->size = static_cast<WORD>(sizeof(StormBlockHeader) + userSize);
        freeBlock->alignPadding = header->AlignPadding;
        freeBlock->flags = 0x2; // 空闲标志
        freeBlock->next = nullptr;

        // 处理边界检查
        if (header->HasBoundaryCheck()) {
            freeBlock->size += 2;
        }

        // 8字节对齐
        freeBlock->size = (freeBlock->size + 7) & ~7;

        // 尝试合并相邻块
        CoalesceBlocks(heap, freeBlock);

        // 添加到空闲链表
        AddToFreeList(heap, freeBlock);

        // 更新堆统计
        heap->freeCount++;
        heap->allocSize -= static_cast<DWORD>(userSize);
        heap->allocCount--;

        return true;
    }

    StormFreeBlock* StormCompatibleAllocator::FindFreeBlock(SimulatedStormHeap* heap, size_t requiredSize) {
        // 从合适的级别开始查找
        int startLevel = heap->GetFreeListIndex(requiredSize);

        for (int level = startLevel; level < 9; level++) {
            StormFreeBlock* block = static_cast<StormFreeBlock*>(heap->freeList[level]);

            while (block) {
                if (block->size >= requiredSize) {
                    return block;
                }
                block = block->next;
            }
        }

        return nullptr;
    }

    void StormCompatibleAllocator::AddToFreeList(SimulatedStormHeap* heap, StormFreeBlock* block) {
        int level = heap->GetFreeListIndex(block->size);

        // 插入到链表头部
        block->next = static_cast<StormFreeBlock*>(heap->freeList[level]);
        heap->freeList[level] = block;
    }

    void StormCompatibleAllocator::RemoveFromFreeList(SimulatedStormHeap* heap, StormFreeBlock* targetBlock) {
        int level = heap->GetFreeListIndex(targetBlock->size);

        StormFreeBlock* block = static_cast<StormFreeBlock*>(heap->freeList[level]);
        StormFreeBlock* prev = nullptr;

        while (block) {
            if (block == targetBlock) {
                if (prev) {
                    prev->next = block->next;
                }
                else {
                    heap->freeList[level] = block->next;
                }
                return;
            }
            prev = block;
            block = block->next;
        }
    }

    void StormCompatibleAllocator::SetupBlockHeader(StormBlockHeader* header, SimulatedStormHeap* heap, size_t userSize, DWORD flags) {
        header->HeapPtr = reinterpret_cast<DWORD>(heap);
        header->Size = static_cast<DWORD>(userSize);
        header->AlignPadding = 0;
        header->Flags = static_cast<BYTE>(flags & 0xFF);
        header->Magic = 0x6F6D;

        // 设置边界检查魔数
        if (flags & 0x1) {
            WORD* boundaryMagic = header->GetBoundaryMagic();
            if (boundaryMagic) {
                *boundaryMagic = static_cast<WORD>(BOUNDARY_MAGIC);
            }
        }
    }

    bool StormCompatibleAllocator::ValidateBlockHeader(const StormBlockHeader* header) {
        if (!header) return false;

        __try {
            // 检查魔数
            if (header->Magic != 0x6F6D) return false;

            // 检查大小合理性
            if (header->Size == 0 || header->Size > 0x10000000) return false;

            // 检查堆指针
            SimulatedStormHeap* heap = reinterpret_cast<SimulatedStormHeap*>(header->HeapPtr);
            if (!heap) return false;

            // 检查是否在堆范围内
            if (!heap->ContainsPointer(const_cast<StormBlockHeader*>(header))) return false;

            // 检查边界魔数
            if (header->HasBoundaryCheck()) {
                const WORD* boundaryMagic = const_cast<StormBlockHeader*>(header)->GetBoundaryMagic();
                if (boundaryMagic && *boundaryMagic != BOUNDARY_MAGIC) return false;
            }

            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    void StormCompatibleAllocator::CoalesceBlocks(SimulatedStormHeap* heap, StormFreeBlock* block) {
        // 尝试与后续块合并
        char* blockEnd = reinterpret_cast<char*>(block) + block->size;

        if (blockEnd < heap->memoryEnd) {
            StormFreeBlock* nextBlock = reinterpret_cast<StormFreeBlock*>(blockEnd);

            // 检查下一个块是否是空闲的
            if (nextBlock->IsFree() &&
                reinterpret_cast<char*>(nextBlock) + nextBlock->size <= heap->memoryEnd) {

                // 从空闲链表中移除下一个块
                RemoveFromFreeList(heap, nextBlock);

                // 合并
                block->size += nextBlock->size;
            }
        }

        // 注意：向前合并需要更复杂的算法，这里简化处理
    }

    uint32_t StormCompatibleAllocator::ComputeStormHash(const char* name, bool caseSensitive, DWORD seed) {
        // 模拟Storm_502函数的哈希算法
        uint32_t hash = seed ? seed : 2146271213;
        uint32_t hash2 = static_cast<uint32_t>(-286331154);

        if (name) {
            const char* p = name;
            while (*p) {
                uint8_t c = static_cast<uint8_t>(*p);

                if (!caseSensitive) {
                    if (c >= 'a' && c <= 'z') c -= 32; // 转大写
                    if (c == '/') c = '\\'; // 路径分隔符标准化
                }

                // Storm的哈希算法
                hash ^= (hash2 + hash);
                hash2 += c + 32 * hash2 + hash + 3;
                p++;
            }
        }

        if (hash == 0) hash = 1;
        return hash & 0x7FFFFFFF;
    }

} // namespace StormCompatible